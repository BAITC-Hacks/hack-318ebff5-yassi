<!doctype html>
<html lang="kk">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Крестики-нолики (Tic-Tac-Toe)</title>
    <style>
        :root {
            --bg: #0b1220;
            --card: #111a2e;
            --cell: #0f1830;
            --cellHover: #152145;
            --text: #eaf0ff;
            --muted: #9fb0d2;
            --accent: #7aa2ff;
            --win: #36d399;
            --danger: #ff5c7a;
            --shadow: 0 18px 50px rgba(0, 0, 0, .35);
            --radius: 18px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial;
            background: radial-gradient(900px 600px at 20% 10%, rgba(122, 162, 255, .25), transparent 60%),
                radial-gradient(900px 600px at 80% 90%, rgba(54, 211, 153, .18), transparent 60%),
                var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px;
        }

        .app {
            width: min(980px, 100%);
            display: grid;
            gap: 18px;
            grid-template-columns: 1.1fr .9fr;
            align-items: start;
        }

        @media (max-width: 860px) {
            .app {
                grid-template-columns: 1fr;
            }
        }

        .panel {
            background: linear-gradient(180deg, rgba(255, 255, 255, .04), rgba(255, 255, 255, .02));
            border: 1px solid rgba(255, 255, 255, .08);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
        }

        h1 {
            font-size: clamp(22px, 3vw, 30px);
            margin: 0 0 6px;
            letter-spacing: .2px;
        }

        .sub {
            margin: 0;
            color: var(--muted);
            line-height: 1.4;
            font-size: 14px;
        }

        .board {
            margin-top: 18px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            background: rgba(255, 255, 255, .03);
            padding: 12px;
            border-radius: calc(var(--radius) - 6px);
            border: 1px solid rgba(255, 255, 255, .06);
        }

        .cell {
            aspect-ratio: 1 / 1;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, .08);
            border-radius: 16px;
            background: linear-gradient(180deg, rgba(255, 255, 255, .03), rgba(255, 255, 255, .01));
            display: grid;
            place-items: center;
            font-size: clamp(44px, 7vw, 68px);
            font-weight: 800;
            cursor: pointer;
            user-select: none;
            transition: transform .08s ease, background .15s ease, border-color .15s ease;
            position: relative;
            overflow: hidden;
        }

        .cell:hover {
            background: linear-gradient(180deg, rgba(255, 255, 255, .06), rgba(255, 255, 255, .02));
            border-color: rgba(122, 162, 255, .35);
            transform: translateY(-1px);
        }

        .cell:active {
            transform: translateY(0px) scale(.99);
        }

        .cell[disabled] {
            cursor: not-allowed;
            opacity: .95;
        }

        .mark-x {
            color: #7aa2ff;
            text-shadow: 0 8px 24px rgba(122, 162, 255, .25);
        }

        .mark-o {
            color: #ffb86b;
            text-shadow: 0 8px 24px rgba(255, 184, 107, .22);
        }

        .win {
            outline: 2px solid rgba(54, 211, 153, .8);
            box-shadow: 0 0 0 6px rgba(54, 211, 153, .12);
            border-color: rgba(54, 211, 153, .65) !important;
        }

        .status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-top: 14px;
            padding: 12px 14px;
            border-radius: 14px;
            background: rgba(255, 255, 255, .03);
            border: 1px solid rgba(255, 255, 255, .06);
        }

        .status b {
            font-weight: 800;
        }

        .pill {
            font-size: 12px;
            padding: 6px 10px;
            border-radius: 999px;
            border: 1px solid rgba(255, 255, 255, .14);
            color: var(--text);
            background: rgba(255, 255, 255, .03);
            white-space: nowrap;
        }

        .controls {
            margin-top: 12px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        button {
            appearance: none;
            border: 1px solid rgba(255, 255, 255, .14);
            background: rgba(255, 255, 255, .04);
            color: var(--text);
            padding: 10px 12px;
            border-radius: 14px;
            cursor: pointer;
            font-weight: 700;
            transition: transform .08s ease, border-color .15s ease, background .15s ease;
        }

        button:hover {
            background: rgba(255, 255, 255, .06);
            border-color: rgba(122, 162, 255, .35);
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0px) scale(.99);
        }

        .primary {
            border-color: rgba(122, 162, 255, .55);
            background: rgba(122, 162, 255, .12);
        }

        .danger {
            border-color: rgba(255, 92, 122, .55);
            background: rgba(255, 92, 122, .10);
        }

        .sidegrid {
            display: grid;
            gap: 12px;
        }

        .row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
        }

        .score {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 12px;
        }

        .score .box {
            padding: 12px;
            border-radius: 14px;
            background: rgba(255, 255, 255, .03);
            border: 1px solid rgba(255, 255, 255, .06);
            text-align: center;
        }

        .box .label {
            color: var(--muted);
            font-size: 12px;
            margin-bottom: 6px;
        }

        .box .value {
            font-size: 22px;
            font-weight: 900;
            letter-spacing: .3px;
        }

        .toggle {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255, 255, 255, .06);
            background: rgba(255, 255, 255, .03);
        }

        .toggle input {
            transform: scale(1.15);
        }

        .note {
            margin: 10px 0 0;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.4;
        }

        .footer {
            margin-top: 10px;
            color: rgba(159, 176, 210, .85);
            font-size: 12px;
        }

        /* Small confetti-ish animation */
        .toast {
            margin-top: 12px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255, 255, 255, .08);
            background: rgba(17, 26, 46, .6);
            display: none;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .toast.show {
            display: flex;
        }

        .toast .msg {
            font-weight: 800;
        }
    </style>
</head>

<body>
    <div class="app">
        <div class="panel">
            <h1>Крестики-нолики</h1>
            <p class="sub">Бір файл, бір ойын 🙂 Екі режим: <b>2 ойыншы</b> немесе <b>ботқа қарсы</b> (жеңіл).</p>

            <div class="status" id="status">
                <div id="statusText">Кезек: <b>✕</b></div>
                <div class="pill" id="modePill">Режим: 2 ойыншы</div>
            </div>

            <div class="board" id="board" aria-label="Tic Tac Toe board"></div>

            <div class="controls">
                <button class="primary" id="newRoundBtn">Жаңа раунд</button>
                <button id="resetScoreBtn">Счетты 0 қылу</button>
                <button class="danger" id="clearBtn" title="Тақтаны тазалау">Тақтаны тазалау</button>
            </div>

            <div class="toast" id="toast">
                <div class="msg" id="toastMsg">Жеңіс!</div>
                <button id="toastClose">OK</button>
            </div>

            <div class="footer">Hotkeys: <b>R</b> — жаңа раунд, <b>C</b> — тазалау.</div>
        </div>

        <div class="panel">
            <h2 style="margin:0 0 6px;font-size:18px;">Баптаулар & статистика</h2>
            <p class="sub">Ойыншылар: ✕ және ○. Қаласаң ботты қос.</p>

            <div class="toggle">
                <input type="checkbox" id="botToggle" />
                <label for="botToggle"><b>Ботқа қарсы</b> (бот ○ болады)</label>
            </div>
            <p class="note">Бот “жеңіл”: бірінші мүмкіндікте жеңеді, болмаса бөгейді, әйтпесе ортаны/бұрышты таңдайды.
            </p>

            <div class="score">
                <div class="box">
                    <div class="label">✕ жеңіс</div>
                    <div class="value" id="xWins">0</div>
                </div>
                <div class="box">
                    <div class="label">Тең</div>
                    <div class="value" id="draws">0</div>
                </div>
                <div class="box">
                    <div class="label">○ жеңіс</div>
                    <div class="value" id="oWins">0</div>
                </div>
            </div>

            <div style="margin-top:14px" class="row">
                <div class="pill" id="turnInfo">Кезек: ✕</div>
                <div class="pill" id="roundInfo">Раунд: 1</div>
            </div>

            <p class="note" style="margin-top:12px;">
                Егер қаласаң: түстерін өзгертіп берем, немесе “impossible” бот (minimax) қосып берем.
            </p>
        </div>
    </div>

    <script>
        // ===== State =====
        const boardEl = document.getElementById("board");
        const statusTextEl = document.getElementById("statusText");
        const modePillEl = document.getElementById("modePill");
        const botToggleEl = document.getElementById("botToggle");

        const xWinsEl = document.getElementById("xWins");
        const oWinsEl = document.getElementById("oWins");
        const drawsEl = document.getElementById("draws");

        const turnInfoEl = document.getElementById("turnInfo");
        const roundInfoEl = document.getElementById("roundInfo");

        const newRoundBtn = document.getElementById("newRoundBtn");
        const resetScoreBtn = document.getElementById("resetScoreBtn");
        const clearBtn = document.getElementById("clearBtn");

        const toastEl = document.getElementById("toast");
        const toastMsgEl = document.getElementById("toastMsg");
        const toastCloseBtn = document.getElementById("toastClose");

        let cells = Array(9).fill(null); // "X" | "O" | null
        let current = "X";
        let isGameOver = false;
        let round = 1;

        let score = { X: 0, O: 0, D: 0 };

        const WIN_LINES = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6],
        ];

        // ===== UI build =====
        function buildBoard() {
            boardEl.innerHTML = "";
            for (let i = 0; i < 9; i++) {
                const btn = document.createElement("button");
                btn.className = "cell";
                btn.type = "button";
                btn.setAttribute("aria-label", `cell ${i + 1}`);
                btn.addEventListener("click", () => onCellClick(i));
                boardEl.appendChild(btn);
            }
        }

        function render() {
            const nodeList = boardEl.querySelectorAll(".cell");
            nodeList.forEach((btn, i) => {
                const v = cells[i];
                btn.textContent = v === "X" ? "✕" : v === "O" ? "○" : "";
                btn.disabled = isGameOver || v !== null || (isBotMode() && current === "O");
                btn.classList.toggle("mark-x", v === "X");
                btn.classList.toggle("mark-o", v === "O");
                btn.classList.remove("win");
            });

            const { winner, line } = checkWinner(cells);
            if (winner && line) {
                line.forEach(idx => nodeList[idx].classList.add("win"));
            }

            const modeText = isBotMode() ? "Режим: Ботқа қарсы" : "Режим: 2 ойыншы";
            modePillEl.textContent = modeText;

            const who = current === "X" ? "✕" : "○";
            statusTextEl.innerHTML = isGameOver
                ? statusTextEl.innerHTML
                : `Кезек: <b>${who}</b>`;

            turnInfoEl.textContent = `Кезек: ${who}`;
            roundInfoEl.textContent = `Раунд: ${round}`;

            xWinsEl.textContent = String(score.X);
            oWinsEl.textContent = String(score.O);
            drawsEl.textContent = String(score.D);
        }

        function isBotMode() {
            return botToggleEl.checked;
        }

        // ===== Game logic =====
        function onCellClick(i) {
            if (isGameOver) return;
            if (cells[i] !== null) return;
            if (isBotMode() && current === "O") return;

            makeMove(i, current);

            const outcome = finalizeIfEnded();
            if (!outcome.ended) {
                current = current === "X" ? "O" : "X";
                render();

                if (isBotMode() && current === "O" && !isGameOver) {
                    setTimeout(botMove, 260);
                }
            }
        }

        function makeMove(i, player) {
            cells[i] = player;
        }

        function checkWinner(state) {
            for (const line of WIN_LINES) {
                const [a, b, c] = line;
                if (state[a] && state[a] === state[b] && state[a] === state[c]) {
                    return { winner: state[a], line };
                }
            }
            return { winner: null, line: null };
        }

        function finalizeIfEnded() {
            const { winner } = checkWinner(cells);
            if (winner) {
                isGameOver = true;
                score[winner] += 1;
                statusTextEl.innerHTML = `Жеңімпаз: <b>${winner === "X" ? "✕" : "○"}</b>`;
                showToast(`Жеңімпаз: ${winner === "X" ? "✕" : "○"}`);
                render();
                return { ended: true, winner };
            }

            const isDraw = cells.every(v => v !== null);
            if (isDraw) {
                isGameOver = true;
                score.D += 1;
                statusTextEl.innerHTML = `Нәтиже: <b>ТЕҢ</b>`;
                showToast("ТЕҢ!");
                render();
                return { ended: true, winner: null };
            }
            return { ended: false, winner: null };
        }

        // ===== Bot (easy but decent) =====
        function botMove() {
            if (isGameOver) return;

            // Bot plays "O"
            const move = chooseBotMove(cells);
            if (move == null) return;

            makeMove(move, "O");
            const outcome = finalizeIfEnded();
            if (!outcome.ended) {
                current = "X";
                render();
            }
        }

        function chooseBotMove(state) {
            const empty = state
                .map((v, idx) => (v === null ? idx : null))
                .filter(v => v !== null);

            if (empty.length === 0) return null;

            // 1) Win if possible
            const win = findTactical(state, "O");
            if (win != null) return win;

            // 2) Block X if needed
            const block = findTactical(state, "X");
            if (block != null) return block;

            // 3) Take center
            if (state[4] === null) return 4;

            // 4) Take a corner
            const corners = [0, 2, 6, 8].filter(i => state[i] === null);
            if (corners.length) return corners[Math.floor(Math.random() * corners.length)];

            // 5) Anything
            return empty[Math.floor(Math.random() * empty.length)];
        }

        function findTactical(state, player) {
            // If player has 2 in a line and one empty -> return that empty index
            for (const line of WIN_LINES) {
                const vals = line.map(i => state[i]);
                const countPlayer = vals.filter(v => v === player).length;
                const countEmpty = vals.filter(v => v === null).length;
                if (countPlayer === 2 && countEmpty === 1) {
                    const emptyIdx = line.find(i => state[i] === null);
                    return emptyIdx ?? null;
                }
            }
            return null;
        }

        // ===== Controls =====
        function clearBoard(keepTurn = true) {
            cells = Array(9).fill(null);
            isGameOver = false;
            hideToast();
            if (!keepTurn) current = "X";
            statusTextEl.innerHTML = `Кезек: <b>${current === "X" ? "✕" : "○"}</b>`;
            render();

            if (isBotMode() && current === "O") {
                setTimeout(botMove, 220);
            }
        }

        function newRound() {
            round += 1;
            current = "X";
            clearBoard(true);
        }

        function resetScore() {
            score = { X: 0, O: 0, D: 0 };
            round = 1;
            current = "X";
            clearBoard(true);
            render();
            showToast("Счет 0 болды.");
        }

        function showToast(msg) {
            toastMsgEl.textContent = msg;
            toastEl.classList.add("show");
        }
        function hideToast() {
            toastEl.classList.remove("show");
        }

        // ===== Events =====
        botToggleEl.addEventListener("change", () => {
            modePillEl.textContent = isBotMode() ? "Режим: Ботқа қарсы" : "Режим: 2 ойыншы";
            // If switched on mid-game and it's O's turn -> bot moves
            render();
            if (isBotMode() && current === "O" && !isGameOver) {
                setTimeout(botMove, 250);
            }
        });

        newRoundBtn.addEventListener("click", newRound);
        clearBtn.addEventListener("click", () => clearBoard(true));
        resetScoreBtn.addEventListener("click", resetScore);
        toastCloseBtn.addEventListener("click", hideToast);

        document.addEventListener("keydown", (e) => {
            if (e.key.toLowerCase() === "r") newRound();
            if (e.key.toLowerCase() === "c") clearBoard(true);
        });

        // ===== Init =====
        buildBoard();
        render();
    </script>
</body>

</html>
